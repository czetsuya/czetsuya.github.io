Files in this folder
--------------------
readme.txt                          This file
fruitList.txt						List of fruits

Instructions
--------------------
1) Create and write your code in recipeChecker.sh
2) Submit only recipeChecker.sh